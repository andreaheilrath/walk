export const clock = (p) => {
  let cx, cy;
  let secondsRadius;
  let minutesRadius;
  let hoursRadius;
  let clockDiameter;

  p.setup = () => {
    p.createCanvas(720, 400);
    p.stroke(255);

    const radius = p.min(p.width, p.height) / 2;
    secondsRadius = radius * 0.71;
    minutesRadius = radius * 0.6;
    hoursRadius = radius * 0.5;
    clockDiameter = radius * 1.7;

    cx = p.width / 2;
    cy = p.height / 2;
  };


  p.draw = () => {
    // Draw the clock background
    p.background(100*p.pAccelerationX, 100*p.pAccelerationY, 100*p.pAccelerationZ);
    p.fill = (255);
    p.ellipse(p.width/2 + p.int(100*p.sin(p.millis()/400)), p.height/2 + p.int(100*p.cos(p.millis()/400)), 25, 25);


  };
};
